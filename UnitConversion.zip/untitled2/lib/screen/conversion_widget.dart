import 'package:flutter/material.dart';

class ConversionWidget extends StatefulWidget {
  final List<String> units;
  final Map<String, double> conversionRates;

  ConversionWidget({required this.units, required this.conversionRates});

  @override
  _ConversionWidgetState createState() => _ConversionWidgetState();
}

class _ConversionWidgetState extends State<ConversionWidget> {
  late String _fromUnit;
  late String _toUnit;
  double _inputValue = 0.0;
  double _convertedValue = 0.0;

  @override
  void initState() {
    super.initState();
    _fromUnit = widget.units.first;
    _toUnit = widget.units.first;
  }

  void _convert() {
    setState(() {
      double conversionRate = widget.conversionRates[_toUnit]! / widget.conversionRates[_fromUnit]!;
      _convertedValue = _inputValue * conversionRate;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextField(
            decoration: InputDecoration(labelText: 'Enter value'),
            keyboardType: TextInputType.number,
            onChanged: (value) {
              _inputValue = double.tryParse(value) ?? 0.0;
            },
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              DropdownButton<String>(
                value: _fromUnit,
                onChanged: (newValue) {
                  setState(() {
                    _fromUnit = newValue!;
                  });
                },
                items: widget.units.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              Icon(Icons.arrow_forward),
              DropdownButton<String>(
                value: _toUnit,
                onChanged: (newValue) {
                  setState(() {
                    _toUnit = newValue!;
                  });
                },
                items: widget.units.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
            ],
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: _convert,
            child: Text('Convert'),
          ),
          SizedBox(height: 20),
          Text('Converted Value: $_convertedValue'),
        ],
      ),
    );
  }
}
