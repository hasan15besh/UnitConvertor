import 'package:flutter/material.dart';
import 'length_conversion_screen.dart';
import 'weight_conversion_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Unit Converter'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              child: Text('Convert Length'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LengthConversionScreen()),
                );
              },
            ),
            ElevatedButton(
              child: Text('Convert Weight'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => WeightConversionScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
