import 'package:flutter/material.dart';
import '../../widgets/conversion_widget.dart';
import 'conversion_widget.dart';

class LengthConversionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Length Conversion'),
      ),
      body: ConversionWidget(
        units: ['Meters', 'Kilometers', 'Centimeters', 'Millimeters', 'Miles', 'Yards', 'Feet', 'Inches'],
        conversionRates: {
          'Meters': 1.0,
          'Kilometers': 0.001,
          'Centimeters': 100.0,
          'Millimeters': 1000.0,
          'Miles': 0.000621371,
          'Yards': 1.09361,
          'Feet': 3.28084,
          'Inches': 39.3701,
        },
      ),
    );
  }
}
