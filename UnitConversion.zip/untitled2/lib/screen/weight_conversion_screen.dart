import 'package:flutter/material.dart';
import '../widgets/conversion_widget.dart';
import 'conversion_widget.dart';  // Correct import path

class WeightConversionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Weight Conversion'),
      ),
      body: ConversionWidget(
        units: ['Kilograms', 'Grams', 'Milligrams', 'Pounds', 'Ounces'],
        conversionRates: {
          'Kilograms': 1.0,
          'Grams': 1000.0,
          'Milligrams': 1000000.0,
          'Pounds': 2.20462,
          'Ounces': 35.274,
        },
      ),
    );
  }
}
